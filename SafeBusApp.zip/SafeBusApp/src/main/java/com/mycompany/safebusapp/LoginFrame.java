/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class LoginFrame extends Frame implements ActionListener {
    TextField tfUser, tfPass;
    Choice roleChoice;
    Button btnLogin;

    public LoginFrame() {
        setLayout(null);
        setTitle("SafeBus Login");
        setSize(400, 300);

        Label lbl1 = new Label("Username:");
        lbl1.setBounds(50, 50, 80, 25);
        add(lbl1);

        tfUser = new TextField();
        tfUser.setBounds(150, 50, 200, 25);
        add(tfUser);

        Label lbl2 = new Label("Password:");
        lbl2.setBounds(50, 90, 80, 25);
        add(lbl2);

        tfPass = new TextField();
        tfPass.setEchoChar('*');
        tfPass.setBounds(150, 90, 200, 25);
        add(tfPass);

        Label lbl3 = new Label("Role:");
        lbl3.setBounds(50, 130, 80, 25);
        add(lbl3);

        roleChoice = new Choice();
        roleChoice.add("user");
        roleChoice.add("admin");
        roleChoice.setBounds(150, 130, 200, 25);
        add(roleChoice);

        btnLogin = new Button("Login");
        btnLogin.setBounds(150, 180, 100, 30);
        btnLogin.addActionListener(this);
        add(btnLogin);
        Button btnRegister = new Button("Register");
        btnRegister.setBounds(150, 180, 100, 30);
        add(btnRegister);
        btnRegister.addActionListener(e -> new RegisterFrame());


        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String user = tfUser.getText();
        String pass = tfPass.getText();
        String role = roleChoice.getSelectedItem();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM users WHERE username=? AND password=? AND role=?")) {
            ps.setString(1, user);
            ps.setString(2, pass);
            ps.setString(3, role);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                dispose();
                if (role.equals("admin")) {
                    new AdminDashboard(user);
                } else {
                    new UserDashboard(user);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid credentials!");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
