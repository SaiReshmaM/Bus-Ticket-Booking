/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.awt.*;
import java.sql.*;

public class TicketSearch extends Frame {
    TextField tfId;
    TextArea ta;
    Button btnSearch;
    String user;

    public TicketSearch(String user) {
        this.user = user;
        setTitle("Search Ticket");
        setLayout(new FlowLayout());

        tfId = new TextField(10);
        btnSearch = new Button("Search");
        ta = new TextArea(10, 40);

        add(new Label("Ticket ID:"));
        add(tfId);
        add(btnSearch);
        add(ta);

        btnSearch.addActionListener(e -> search());

        setSize(500, 300);
        setVisible(true);
    }

    private void search() {
        int id = Integer.parseInt(tfId.getText());

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM tickets WHERE id=?")) {
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                ta.setText("Ticket ID: " + rs.getInt("id") +
                           "\nUser: " + rs.getString("user") +
                           "\nFrom: " + rs.getString("source") +
                           "\nTo: " + rs.getString("destination") +
                           "\nDate: " + rs.getString("date") +
                           "\nSeat: " + rs.getString("seatNo"));
            } else {
                ta.setText("Ticket not found.");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
