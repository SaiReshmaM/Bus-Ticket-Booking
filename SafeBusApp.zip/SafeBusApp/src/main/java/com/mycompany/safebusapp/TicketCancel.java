/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.awt.*;
import javax.swing.*;
import java.sql.*;

public class TicketCancel extends Frame {
    TextField tfTicketId;
    Button btnCancel;
    String user;

    public TicketCancel(String user) {
        this.user = user;
        setTitle("Cancel Ticket");
        setLayout(null);

        Label l1 = new Label("Ticket ID:");
        l1.setBounds(50, 70, 80, 25);
        add(l1);

        tfTicketId = new TextField();
        tfTicketId.setBounds(150, 70, 150, 25);
        add(tfTicketId);

        btnCancel = new Button("Cancel");
        btnCancel.setBounds(150, 120, 80, 30);
        add(btnCancel);

        btnCancel.addActionListener(e -> cancelTicket());

        setSize(350, 200);
        setVisible(true);
    }

    private void cancelTicket() {
        String ticketId = tfTicketId.getText();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("DELETE FROM tickets WHERE id=? AND user=?")) {
            pst.setInt(1, Integer.parseInt(ticketId));
            pst.setString(2, user);
            int result = pst.executeUpdate();
            if (result > 0) {
                JOptionPane.showMessageDialog(this, "Ticket cancelled successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Ticket not found or not yours.");
            }
            dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
