/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */

import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class TicketBooking extends JFrame {
    JTextField tfSource, tfDest, tfDate, tfSeat;
    JButton btnBook;
    String user;

    public TicketBooking(String user) {
        this.user = user;
        setTitle("Book Ticket");
        setLayout(null);

        JLabel l1 = new JLabel("Source:");
        l1.setBounds(50, 50, 100, 25);
        add(l1);
        tfSource = new JTextField();
        tfSource.setBounds(160, 50, 150, 25);
        add(tfSource);

        JLabel l2 = new JLabel("Destination:");
        l2.setBounds(50, 90, 100, 25);
        add(l2);
        tfDest = new JTextField();
        tfDest.setBounds(160, 90, 150, 25);
        add(tfDest);

        JLabel l3 = new JLabel("Date (YYYY-MM-DD):");
        l3.setBounds(50, 130, 150, 25);
        add(l3);
        tfDate = new JTextField();
        tfDate.setBounds(200, 130, 110, 25);
        add(tfDate);

        JLabel l4 = new JLabel("Seat No:");
        l4.setBounds(50, 170, 100, 25);
        add(l4);
        tfSeat = new JTextField();
        tfSeat.setBounds(160, 170, 150, 25);
        add(tfSeat);

        btnBook = new JButton("Book");
        btnBook.setBounds(150, 220, 100, 30);
        add(btnBook);

        // Add click listener
        btnBook.addActionListener(e -> bookTicket());

        setSize(400, 330);
        setLocationRelativeTo(null); // Center the window
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setVisible(true);
    }

    private void bookTicket() {
        String src = tfSource.getText();
        String dest = tfDest.getText();
        String date = tfDate.getText();
        String seat = tfSeat.getText();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("INSERT INTO tickets (user, source, destination, date, seatNo) VALUES (?, ?, ?, ?, ?)")) {
            pst.setString(1, user);
            pst.setString(2, src);
            pst.setString(3, dest);
            pst.setString(4, date);
            pst.setString(5, seat);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Ticket booked successfully!");
            dispose();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error booking ticket: " + ex.getMessage());
        }
    }

    // Optional: Add a main method for testing
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TicketBooking("user1"));
    }
}
