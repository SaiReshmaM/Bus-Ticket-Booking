/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.awt.*;

public class AdminDashboard extends Frame {
    public AdminDashboard(String user) {
        setTitle("Admin Dashboard - Welcome " + user);
        setLayout(new FlowLayout());

        Button book = new Button("Book Ticket");
        Button cancel = new Button("Cancel Ticket");
        Button search = new Button("Search Ticket");
        Button view = new Button("View Tickets");
        Button transactions = new Button("View Transactions");

        add(book); add(cancel); add(search); add(view); add(transactions);

        book.addActionListener(e -> new TicketBooking(user));
        cancel.addActionListener(e -> new TicketCancel(user));
        search.addActionListener(e -> new TicketSearch(user));
        view.addActionListener(e -> new TicketView(user));
        transactions.addActionListener(e -> new TransactionView(user));

        setSize(400, 300);
        setVisible(true);
    }
}
