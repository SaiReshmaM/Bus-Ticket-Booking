/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.awt.*;
import java.sql.*;

public class TransactionView extends Frame {
    TextArea ta;

    public TransactionView(String user) {
        setTitle("View Transactions");
        setLayout(new FlowLayout());

        ta = new TextArea(20, 50);
        add(ta);

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM transactions")) {

            while (rs.next()) {
                ta.append("Transaction ID: " + rs.getInt("id") +
                          ", User: " + rs.getString("user") +
                          ", Ticket ID: " + rs.getInt("ticketId") +
                          ", Amount: " + rs.getDouble("amount") +
                          ", Date: " + rs.getString("date") + "\n");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        setSize(600, 400);
        setVisible(true);
    }
}
