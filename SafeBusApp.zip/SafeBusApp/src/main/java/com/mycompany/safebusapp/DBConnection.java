/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.sql.*;
public class DBConnection {
     static Connection con;

    public static Connection getConnection() {
    try {
        if (con == null || con.isClosed()) {  // <-- important check added
            Class.forName("org.sqlite.JDBC");
            con = DriverManager.getConnection("jdbc:sqlite:safebus.db");
            createTables();
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return con;
}
    


    private static void createTables() throws SQLException {
        Statement stmt = con.createStatement();

        stmt.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT, role TEXT)");
        stmt.execute("CREATE TABLE IF NOT EXISTS tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, source TEXT, destination TEXT, date TEXT, seatNo TEXT)");
        stmt.execute("CREATE TABLE IF NOT EXISTS transactions (id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, ticketId INTEGER, amount REAL, date TEXT)");

    }
}
