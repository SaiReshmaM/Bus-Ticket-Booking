/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
import java.awt.*;
import java.sql.*;

public class TicketView extends Frame {
    TextArea ta;
    String user;

    public TicketView(String user) {
        this.user = user;
        setTitle("View Tickets");
        setLayout(new FlowLayout());

        ta = new TextArea(20, 50);
        add(ta);

        displayTickets();

        setSize(600, 400);
        setVisible(true);
    }

    private void displayTickets() {
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("SELECT * FROM tickets WHERE user=?")) {
            pst.setString(1, user);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                ta.append("ID: " + rs.getInt("id") +
                          ", From: " + rs.getString("source") +
                          ", To: " + rs.getString("destination") +
                          ", Date: " + rs.getString("date") +
                          ", Seat: " + rs.getString("seatNo") + "\n");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
