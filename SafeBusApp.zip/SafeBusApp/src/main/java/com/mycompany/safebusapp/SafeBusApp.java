/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.safebusapp;

/**
 *
 * @author NAVYASRI
 */
public class SafeBusApp {

    public static void main(String[] args) {
         new LoginFrame();
    }
}
