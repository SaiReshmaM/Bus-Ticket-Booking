package com.mycompany.safebusapp;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author NAVYASRI
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class RegisterFrame extends Frame {
    TextField tfUsername, tfPassword;
    Choice roleChoice;
    Button btnRegister, btnCancel;

    public RegisterFrame() {
        setTitle("User Registration");
        setSize(350, 250);
        setLayout(null);
        setLocationRelativeTo(null);

        Label l1 = new Label("Username:");
        l1.setBounds(50, 50, 80, 25);
        add(l1);

        tfUsername = new TextField();
        tfUsername.setBounds(140, 50, 150, 25);
        add(tfUsername);

        Label l2 = new Label("Password:");
        l2.setBounds(50, 90, 80, 25);
        add(l2);

        tfPassword = new TextField();
        tfPassword.setEchoChar('*');
        tfPassword.setBounds(140, 90, 150, 25);
        add(tfPassword);

        Label l3 = new Label("Role:");
        l3.setBounds(50, 130, 80, 25);
        add(l3);

        roleChoice = new Choice();
        roleChoice.add("user");
        roleChoice.add("admin");
        roleChoice.setBounds(140, 130, 150, 25);
        add(roleChoice);

        btnRegister = new Button("Register");
        btnRegister.setBounds(80, 170, 80, 30);
        add(btnRegister);

        btnCancel = new Button("Cancel");
        btnCancel.setBounds(180, 170, 80, 30);
        add(btnCancel);

        btnRegister.addActionListener(e -> registerUser());
        btnCancel.addActionListener(e -> dispose());

        setVisible(true);
    }

    private void registerUser() {
        String username = tfUsername.getText();
        String password = tfPassword.getText();
        String role = roleChoice.getSelectedItem();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter all fields.");
            return;
        }

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = con.prepareStatement("INSERT INTO users (username, password, role) VALUES (?, ?, ?)")) {
            pst.setString(1, username);
            pst.setString(2, password);
            pst.setString(3, role);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "User registered successfully!");
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
